﻿using MapsterMapper;

using Microsoft.AspNetCore.Mvc;

using PaySpace.Calculator.API.Models;
using PaySpace.Calculator.Data.Models;
using PaySpace.Calculator.Services.Abstractions;
using PaySpace.Calculator.Services.Exceptions;
using PaySpace.Calculator.Services.Models;

namespace PaySpace.Calculator.API.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public sealed class CalculatorController(
        ILogger<CalculatorController> logger,
        IHistoryService historyService,
        IMapper mapper,IPostalCodeService postalCodeService,
        IFlatRateCalculator flatRateCalculatorService,
        IFlatValueCalculator flatValueCalculatorService,
        IProgressiveCalculator progressiveCalculatorService,
        ICalculatorSettingsService calculatorSettingsService)
        : ControllerBase
    {
        [HttpPost("calculate-tax")]
        public async Task<ActionResult<CalculateResult>> Calculate(CalculateRequest request)
        {
            try
            {

                var result = new CalculateResult();
                var postalCode = await postalCodeService.CalculatorTypeAsync(request.PostalCode ?? "Unknown");
                var calculatorSettings = await calculatorSettingsService.GetSettingsAsync(postalCode.Value);
                switch (postalCode)
                {
                    case CalculatorType.Progressive:
                        result = await progressiveCalculatorService.CalculateAsync(request.Income, calculatorSettings);
                        break;
                    case CalculatorType.FlatRate:

                        result = await flatRateCalculatorService.CalculateAsync(request.Income, calculatorSettings);
                        break;   
                    case CalculatorType.FlatValue:
                        result = await flatValueCalculatorService.CalculateAsync(request.Income, calculatorSettings);
                        break;
                    default:
                        return this.BadRequest("Provide a valid postal code");
                }
                await historyService.AddAsync(new CalculatorHistory
                {
                    Tax = result.Tax,
                    Calculator = result.Calculator,
                    PostalCode = request.PostalCode ?? "Unknown",
                    Income = request.Income
                });

                return this.Ok(mapper.Map<CalculateResultDto>(result));
            }
            catch (CalculatorException e)
            {
                logger.LogError(e, e.Message);

                return this.BadRequest(e.Message);
            }
        }

        [HttpGet("history")]
        public async Task<ActionResult<List<CalculatorHistory>>> History()
        {
            var history = await historyService.GetHistoryAsync();

            return this.Ok(mapper.Map<List<CalculatorHistoryDto>>(history));
        }

        [HttpGet("GetHistoryById/{Id}")]
        public async Task<ActionResult<CalculatorHistory>> GetHistoryById(long Id)
        {
            var history = await historyService.GetHistoryAsync(Id);

            return this.Ok(mapper.Map<CalculatorHistoryDto>(history));
        }

        [HttpDelete("DeleteHistory/{Id}")]
        public async Task<ActionResult> DeleteHistory(long Id)
        {
            await historyService.DeleteHistoryAsync(Id);
            return this.Ok();
        }
    }
}