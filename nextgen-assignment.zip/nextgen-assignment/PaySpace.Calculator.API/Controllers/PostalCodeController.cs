﻿using MapsterMapper;
using Microsoft.AspNetCore.Mvc;
using PaySpace.Calculator.API.Models;
using PaySpace.Calculator.Services.Abstractions;

namespace PaySpace.Calculator.API.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class PostalCodeController(ILogger<PostalCodeController> logger,
        IMapper mapper,IPostalCodeService postalCodeService) : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult> GetPostalCodes()
        {
            try
            {
                var responds = await postalCodeService.GetPostalCodesAsync();
                return Ok(mapper.Map<List<PostalCodeDto>>(responds));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
