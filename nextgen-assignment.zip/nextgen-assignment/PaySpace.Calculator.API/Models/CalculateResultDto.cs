﻿namespace PaySpace.Calculator.API.Models
{
    public sealed class CalculateResultDto
    {
        public string Calculator { get; set; }

        public decimal Tax { get; set; }
    }
}