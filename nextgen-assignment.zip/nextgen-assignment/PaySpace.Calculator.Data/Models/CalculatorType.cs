﻿namespace PaySpace.Calculator.Data.Models
{
    public enum CalculatorType
    {
        Progressive,
        FlatValue,
        FlatRate
    }
}