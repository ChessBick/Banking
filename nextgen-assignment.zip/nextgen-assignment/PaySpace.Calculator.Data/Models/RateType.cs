﻿namespace PaySpace.Calculator.Data.Models
{
    public enum RateType
    {
        Percentage,
        Amount
    }
}