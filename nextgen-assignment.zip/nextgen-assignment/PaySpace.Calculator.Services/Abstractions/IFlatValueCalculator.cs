﻿using PaySpace.Calculator.Data.Models;
using PaySpace.Calculator.Services.Models;

namespace PaySpace.Calculator.Services.Abstractions
{
    public interface IFlatValueCalculator
    {
        Task<CalculateResult> CalculateAsync(decimal income, List<CalculatorSetting> calculatorSettings = null!);

    }
}