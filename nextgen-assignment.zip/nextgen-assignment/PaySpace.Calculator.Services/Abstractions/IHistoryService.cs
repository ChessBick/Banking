﻿using PaySpace.Calculator.Data.Models;

namespace PaySpace.Calculator.Services.Abstractions
{
    public interface IHistoryService
    {
        Task<List<CalculatorHistory>> GetHistoryAsync();
        Task<CalculatorHistory> GetHistoryAsync(long id);

        Task AddAsync(CalculatorHistory calculatorHistory);
        Task UpdateAsync(CalculatorHistory calculatorHistory);
        Task DeleteHistoryAsync(long Id);
    }
}