﻿using PaySpace.Calculator.Data.Models;
using PaySpace.Calculator.Services.Abstractions;
using PaySpace.Calculator.Services.Models;

namespace PaySpace.Calculator.Services.Calculators
{
    internal sealed class FlatValueCalculator: IFlatValueCalculator
    {
        public async Task<CalculateResult> CalculateAsync(decimal income, List<CalculatorSetting> calculatorSettings = null!)
        {
            var result = new CalculateResult();
            if (calculatorSettings != null)
            {
                var calculatorSetting = calculatorSettings.Find(item =>income >= item.From && (item.To == null || income <= item.To));
                if (calculatorSetting != null)
                {
                    if (calculatorSetting.RateType == RateType.Percentage)
                    {
                        result.Tax = calculatorSetting.Rate;
                    }
                    else
                    {
                        result.Tax = calculatorSetting.Rate;
                    }
                }
                else
                {
                    result.Tax = 0.0m;
                }
            }
            else
            {
                result.Tax = 0.0m;
            }
            result.Calculator = CalculatorType.FlatValue;
            return result;
        }
    }
}