﻿using Microsoft.Extensions.Caching.Memory;
using Moq;

using NUnit.Framework;
using PaySpace.Calculator.Data;
using PaySpace.Calculator.Data.Models;
using PaySpace.Calculator.Services;
using PaySpace.Calculator.Services.Abstractions;
using PaySpace.Calculator.Services.Calculators;
using PaySpace.Calculator.Services.Models;

namespace PaySpace.Calculator.Tests
{
    [TestFixture]
    internal sealed class FlatRateCalculatorTests
    {
        private FlatRateCalculator flatRateService;
        private CalculatorSettingsService settingsService;

        [SetUp]
        public void Setup()
        {
            var _calculator = new Mock<IFlatRateCalculator>();
            var _settingsService = new Mock<ICalculatorSettingsService>();
            var _cache = new Mock<IMemoryCache>();
            var _db = new Mock<CalculatorContext>();
            _calculator.Setup(x => x.CalculateAsync(It.IsAny<decimal>(),It.IsAny<List<CalculatorSetting>>())).Verifiable();
            _settingsService.Setup(x => x.GetSettingsAsync(It.IsAny<CalculatorType>())).Verifiable();

            flatRateService = new FlatRateCalculator();
            settingsService = new CalculatorSettingsService(_db.Object, _cache.Object);

        }

        [TestCase(-1, 0)]
        [TestCase(999999, 174999.825)]
        [TestCase(1000, 175)]
        [TestCase(5, 0.875)]
        public async Task Calculate_Should_Return_Expected_Tax(decimal income, decimal expectedTax)
        {
            // Arrange

            // Act
            var settings = await settingsService.GetSettingsAsync(CalculatorType.FlatRate);
            var results = await flatRateService.CalculateAsync(income,settings);

            // Assert
        }
    }
}