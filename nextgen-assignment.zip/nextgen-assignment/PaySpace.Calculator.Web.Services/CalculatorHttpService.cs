﻿using System.Net.Http.Json;
using System.Text;
using Newtonsoft.Json;
using PaySpace.Calculator.Web.Services.Abstractions;
using PaySpace.Calculator.Web.Services.Models;

namespace PaySpace.Calculator.Web.Services
{
    public class CalculatorHttpService : ICalculatorHttpService
    {
        private readonly HttpClient httpClient;
        public CalculatorHttpService(IHttpClientFactory httpClientFactory)
        {
            httpClient = httpClientFactory.CreateClient("CalculatorClient");
        }
        public async Task<List<PostalCode>> GetPostalCodesAsync()
        {
            var response = await httpClient.GetAsync("api/postalcode");
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Cannot fetch postal codes, status code: {response.StatusCode}");
            }

            return await response.Content.ReadFromJsonAsync<List<PostalCode>>() ?? [];
        }

        public async Task<List<CalculatorHistory>> GetHistoryAsync()
        {
            var response = await httpClient.GetAsync("api/Calculator/history");
            return await response.Content.ReadFromJsonAsync<List<CalculatorHistory>>() ?? [];
        }

        public async Task<CalculateResult> CalculateTaxAsync(CalculateRequest calculationRequest)
        {
            var httpContent = new StringContent(JsonConvert.SerializeObject(calculationRequest),
                        Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync("api/Calculator/calculate-tax", httpContent);
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Cannot fetch postal codes, status code: {response.StatusCode}");
            }
            return await response.Content.ReadFromJsonAsync<CalculateResult>() ?? new();
        }

        public Task<bool> DeleteHistory(CalculateRequest calculationRequest)
        {
            throw new NotImplementedException();
        }
    }
}