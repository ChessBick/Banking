﻿namespace PaySpace.Calculator.Web.Services.Models
{
    public sealed class CalculateResult
    {
        public string Calculator { get; set; }

        public decimal Tax { get; set; }
    }
}