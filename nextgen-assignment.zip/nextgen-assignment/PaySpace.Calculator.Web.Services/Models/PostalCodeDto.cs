﻿namespace PaySpace.Calculator.Web.Services.Models
{
    public sealed class PostalCode
    {
        public string Code { get; set; }
    }
}