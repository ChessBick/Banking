﻿using Microsoft.Extensions.DependencyInjection;

using PaySpace.Calculator.Web.Services.Abstractions;

namespace PaySpace.Calculator.Web.Services
{
    public static class ServiceCollectionExtensions
    {
        public static void AddCalculatorHttpServices(this IServiceCollection services)
        {
            services.AddScoped<ICalculatorHttpService, CalculatorHttpService>();
            services.AddHttpClient("CalculatorClient", client =>
            {
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.Timeout = TimeSpan.FromSeconds(30);
                client.BaseAddress = new Uri("https://localhost:7119/");
            });
            services.AddTransient<ICalculatorHttpService,CalculatorHttpService>();
        }
    }
}