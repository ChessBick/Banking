using PaySpace.Calculator.Web.Services.Models;

namespace PaySpace.Calculator.Web.Models
{
    public sealed class CalculatorHistoryViewModel
    {
        public List<CalculatorHistory>? CalculatorHistory { get; set; }
    }
}